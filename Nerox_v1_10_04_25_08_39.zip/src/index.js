import { config } from 'dotenv';
import { log } from './logger.js';
import { availableParallelism } from 'node:os';
import { ClusterManager, HeartbeatManager } from 'discord-hybrid-sharding';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Load Environment Variables
config();

const mainFile = './nerox.js';
const __dirname = dirname(fileURLToPath(import.meta.url));
const file = resolve(__dirname, mainFile);

const clusterManager = new ClusterManager(file, {
    respawn: true,
    mode: 'process',
    restarts: {
        max: 10,
        interval: 10_000,
    },
    totalShards: 'auto',
    totalClusters: availableParallelism(),
    token: "MTM0ODU5MDg1MTQzNzM2NzMyNw.GACe9w.b3GQdepVQM7RFs1HWOC9q1-TrgpY6uerDKURGQ",
});

// Heartbeat Manager
clusterManager.extend(new HeartbeatManager({
    interval: 2000,
    maxMissedHeartbeats: 5,
}));

// Spawn Clusters
clusterManager.spawn({ timeout: -1 });

log("Bot started successfully!", "info");