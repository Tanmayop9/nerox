
export class Event {
}
/**@codeStyle - https://google.github.io/styleguide/tsguide.html */
